# 🔐 Port Scanner (Syntecxhub Internship Project)

## 📌 Description
This is a simple TCP Port Scanner built using Python. It scans a target IP or domain and identifies open ports within a specified range.

## 🚀 Features
- Scan custom port ranges
- Multi-threaded scanning (faster)
- Displays open ports
- Saves results to a file

## 🛠️ Technologies Used
- Python
- Socket Programming
- Threading

## ▶️ How to Run

1. Install Python
2. Run the script:

python port_scanner.py

3. Enter:
- Target IP/domain
- Start port
- End port

## 📂 Output
- Displays open ports on screen
- Saves results in scan_results.txt

## 📎 Internship Info
This project was created as part of the Syntecxhub Cybersecurity Internship.
